

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Resultat {
    TreeMap<String, Double> resultat = new TreeMap<>();

    @Override
    public String toString() {
        return "Resultat{" +
                "resultat=" + resultat +
                '}';
    }

    public Resultat() {
    }



    public Resultat(String fn) {
        File f = new File(fn);
        try(Scanner sc = new Scanner(f)) {
            String res;
            final String SEPARATEUR = " ";
            int NbrLignes=0;
            int NbrIdent=0;


            while(sc.hasNextLine()) {
                sc.useLocale(Locale.ENGLISH);
                res = sc.nextLine();
                String erreur ="ERROR";
                String erreur2= "NOT GOOD";

                if(res.equals(erreur)|| res.equals(erreur2)){
                    NbrLignes++;
                }
                else {
                    String mots[] = res.split(SEPARATEUR);
                    String identifiant1 = mots[0];
                    String note = mots[1];
                    Double notefinale = Double.valueOf(note);
                    resultat.put(identifiant1,notefinale);
                    NbrIdent++;
                    NbrLignes++;
                }


            }
            Double max = resultat.values().stream().max(Double::compare).get();
            String keyresmax="";
            for (Map.Entry<String, Double> entry : resultat.entrySet()) {
                if (entry.getValue()==max) {
                    keyresmax = entry.getKey();
                    keyresmax = keyresmax +",";
                }
            }

            Double min = resultat.values().stream().min(Double::compare).get();
            String keyresmin="";

            for (Map.Entry<String, Double> entry : resultat.entrySet()) {
                if (entry.getValue()==min) {
                    keyresmin = entry.getKey();
                    keyresmin = keyresmin +",";
                }
            }
            System.out.println("Plus petite valeur:"+min+"("+keyresmin+")");
            System.out.println("Plus grande valeur:"+  max+"("+keyresmax+")");
            System.out.println("Nombre de lignes:"+NbrLignes);
            System.out.println("Nombre d’identifiants "+NbrIdent);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }



    }



}

