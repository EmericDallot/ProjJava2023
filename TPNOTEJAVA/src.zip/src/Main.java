public class Main {
    public static void main(String[] args) {
        Resultat res = new Resultat("src/input.txt");
    }
}